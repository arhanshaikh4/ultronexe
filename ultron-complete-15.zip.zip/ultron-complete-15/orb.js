// Style 1: classic orb (slim center) | Style 2: solar system
class UltronOrbClassic {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.speaking = false;
    this.listening = false;
    this.t = 0;
    this._raf = null;
    this._alive = true;
    this._resize();
    this._onResize = () => this._resize();
    window.addEventListener('resize', this._onResize);
    this._loop();
  }
  destroy() {
    this._alive = false;
    if (this._raf) cancelAnimationFrame(this._raf);
    this._raf = null;
    if (this._onResize) window.removeEventListener('resize', this._onResize);
  }
  _resize() {
    if (!this.canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = this.canvas.clientWidth || 130;
    const h = this.canvas.clientHeight || 130;
    this.canvas.width = Math.floor(w * dpr);
    this.canvas.height = Math.floor(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.w = w; this.h = h; this.cx = w / 2; this.cy = h / 2;
  }
  setSpeaking(v) { this.speaking = !!v; }
  setListening(v) { this.listening = !!v; }
  _loop() {
    if (!this._alive || !this.ctx) return;
    this.t += 1;
    const ctx = this.ctx;
    const { w, h, cx, cy } = this;
    ctx.clearRect(0, 0, w, h);
    // Slim core — not a fat middle blob
    const pulse = this.speaking ? 1.08 + Math.sin(this.t * 0.18) * 0.04 : 1;
    const R = Math.min(w, h) * 0.14 * pulse; // thinner center
    // outer rings only
    for (let i = 3; i >= 1; i--) {
      ctx.beginPath();
      ctx.arc(cx, cy, R * (2.2 + i * 0.9) + Math.sin(this.t * 0.04 + i) * 1.5, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(0, 210, 255,' + (0.12 + i * 0.05) + ')';
      ctx.lineWidth = 1.2;
      ctx.stroke();
    }
    // small core
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * 1.8);
    g.addColorStop(0, 'rgba(200,255,255,0.95)');
    g.addColorStop(0.5, 'rgba(0,190,255,0.55)');
    g.addColorStop(1, 'rgba(0,40,80,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(cx, cy, R * 1.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(230,255,255,0.9)';
    ctx.beginPath();
    ctx.arc(cx, cy, Math.max(3, R * 0.55), 0, Math.PI * 2);
    ctx.fill();
    // tiny particles
    for (let i = 0; i < 8; i++) {
      const a = this.t * 0.02 + i * 0.8;
      const rr = R * (3.2 + (i % 3) * 0.4);
      ctx.fillStyle = 'rgba(0,230,255,0.3)';
      ctx.beginPath();
      ctx.arc(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
    this._raf = requestAnimationFrame(() => this._loop());
  }
}

class UltronOrbSolar {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.speaking = false;
    this.listening = false;
    this.t = 0;
    this.drag = null;
    this._raf = null;
    this._alive = true;
    this.sun = { ox: 0, oy: 0, size: 12 };
    this.planets = [
      { dist: 30, size: 3.8, speed: 0.036, color: '#c0c0c0', angle: 0.3, ox: 0, oy: 0 },
      { dist: 44, size: 5.5, speed: 0.025, color: '#e8cda0', angle: 1.2, ox: 0, oy: 0 },
      { dist: 60, size: 6, speed: 0.019, color: '#4aa3ff', angle: 2.5, ox: 0, oy: 0 },
      { dist: 76, size: 4.8, speed: 0.015, color: '#e07a5f', angle: 3.7, ox: 0, oy: 0 },
      { dist: 94, size: 9.5, speed: 0.009, color: '#d4a574', angle: 4.6, ox: 0, oy: 0 },
      { dist: 112, size: 8, speed: 0.006, color: '#f0d9a0', angle: 5.4, ox: 0, oy: 0, ring: true }
    ];
    this._resize();
    this._onResize = () => this._resize();
    window.addEventListener('resize', this._onResize);
    this._bindDrag();
    this._loop();
  }
  destroy() {
    this._alive = false;
    if (this._raf) cancelAnimationFrame(this._raf);
    this._raf = null;
    if (this._onResize) window.removeEventListener('resize', this._onResize);
  }
  _resize() {
    if (!this.canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = this.canvas.clientWidth || 160;
    const h = this.canvas.clientHeight || 160;
    this.canvas.width = Math.floor(w * dpr);
    this.canvas.height = Math.floor(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.w = w; this.h = h; this.cx = w / 2; this.cy = h / 2;
  }
  setSpeaking(v) { this.speaking = !!v; }
  setListening(v) { this.listening = !!v; }
  _bindDrag() {
    const pos = (e) => {
      const r = this.canvas.getBoundingClientRect();
      const t = e.touches ? e.touches[0] : e;
      return { x: t.clientX - r.left, y: t.clientY - r.top };
    };
    const hit = (p) => {
      const sx = this.cx + this.sun.ox, sy = this.cy + this.sun.oy;
      if ((p.x - sx) ** 2 + (p.y - sy) ** 2 < (this.sun.size + 14) ** 2) return 'sun';
      for (let i = this.planets.length - 1; i >= 0; i--) {
        const pl = this.planets[i];
        const x = sx + Math.cos(pl.angle) * pl.dist + pl.ox;
        const y = sy + Math.sin(pl.angle) * pl.dist + pl.oy;
        if ((p.x - x) ** 2 + (p.y - y) ** 2 < (pl.size + 12) ** 2) return i;
      }
      return null;
    };
    this._down = (e) => {
      const p = pos(e);
      const i = hit(p);
      if (i == null) return;
      e.preventDefault();
      if (i === 'sun') {
        this.drag = { type: 'sun', dx: p.x - (this.cx + this.sun.ox), dy: p.y - (this.cy + this.sun.oy) };
      } else {
        const pl = this.planets[i];
        const sx = this.cx + this.sun.ox, sy = this.cy + this.sun.oy;
        const x = sx + Math.cos(pl.angle) * pl.dist + pl.ox;
        const y = sy + Math.sin(pl.angle) * pl.dist + pl.oy;
        this.drag = { type: 'planet', i, dx: p.x - x, dy: p.y - y };
      }
    };
    this._move = (e) => {
      if (!this.drag) return;
      e.preventDefault();
      const p = pos(e);
      if (this.drag.type === 'sun') {
        this.sun.ox = p.x - this.drag.dx - this.cx;
        this.sun.oy = p.y - this.drag.dy - this.cy;
      } else {
        const pl = this.planets[this.drag.i];
        const sx = this.cx + this.sun.ox, sy = this.cy + this.sun.oy;
        pl.ox = p.x - this.drag.dx - (sx + Math.cos(pl.angle) * pl.dist);
        pl.oy = p.y - this.drag.dy - (sy + Math.sin(pl.angle) * pl.dist);
      }
    };
    this._up = () => { this.drag = null; };
    this.canvas.addEventListener('mousedown', this._down);
    this.canvas.addEventListener('mousemove', this._move);
    window.addEventListener('mouseup', this._up);
    this.canvas.addEventListener('touchstart', this._down, { passive: false });
    this.canvas.addEventListener('touchmove', this._move, { passive: false });
    window.addEventListener('touchend', this._up);
  }
  _loop() {
    if (!this._alive || !this.ctx) return;
    this.t += 1;
    const ctx = this.ctx;
    const { w, h, cx, cy } = this;
    ctx.clearRect(0, 0, w, h);
    if (!this.drag || this.drag.type !== 'sun') {
      this.sun.ox *= 0.9; this.sun.oy *= 0.9;
      if (Math.abs(this.sun.ox) < 0.3) this.sun.ox = 0;
      if (Math.abs(this.sun.oy) < 0.3) this.sun.oy = 0;
    }
    const sx = cx + this.sun.ox, sy = cy + this.sun.oy;
    const bg = ctx.createRadialGradient(sx, sy, 4, sx, sy, Math.min(w, h) * 0.55);
    bg.addColorStop(0, this.speaking ? 'rgba(255,200,80,0.2)' : 'rgba(80,60,140,0.15)');
    bg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);
    this.planets.forEach(pl => {
      ctx.beginPath();
      ctx.arc(sx, sy, pl.dist, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255,255,255,0.1)';
      ctx.stroke();
    });
    const sunR = this.sun.size + (this.speaking ? Math.sin(this.t * 0.15) * 1.5 : 0);
    const sg = ctx.createRadialGradient(sx, sy, 0, sx, sy, sunR * 2);
    sg.addColorStop(0, '#fff8d0');
    sg.addColorStop(0.4, '#ffcc33');
    sg.addColorStop(1, 'rgba(255,120,0,0)');
    ctx.fillStyle = sg;
    ctx.beginPath();
    ctx.arc(sx, sy, sunR * 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffdd44';
    ctx.beginPath();
    ctx.arc(sx, sy, sunR, 0, Math.PI * 2);
    ctx.fill();
    this.planets.forEach((pl, idx) => {
      const dragging = this.drag && this.drag.type === 'planet' && this.drag.i === idx;
      if (!dragging) {
        pl.angle += pl.speed * (this.listening ? 1.3 : 1);
        pl.ox *= 0.9; pl.oy *= 0.9;
        if (Math.abs(pl.ox) < 0.3) pl.ox = 0;
        if (Math.abs(pl.oy) < 0.3) pl.oy = 0;
      }
      const x = sx + Math.cos(pl.angle) * pl.dist + pl.ox;
      const y = sy + Math.sin(pl.angle) * pl.dist + pl.oy;
      if (pl.ring) {
        ctx.strokeStyle = 'rgba(240,217,160,0.55)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(x, y, pl.size * 2.2, pl.size * 0.7, pl.angle, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.fillStyle = pl.color;
      ctx.beginPath();
      ctx.arc(x, y, pl.size, 0, Math.PI * 2);
      ctx.fill();
    });
    this._raf = requestAnimationFrame(() => this._loop());
  }
}
