// ULTRON.exe by Arhan Shaikh
const WORKER_URL = 'https://ultron.arhan.workers.dev';
const FREE_DAILY_LIMIT = 20;
// Paste your Web Client ID from Google Cloud Console (OAuth 2.0):
const GOOGLE_CLIENT_ID = '833157804241-evpi28t4qsjvd7of17bg3suijiaqpnf2.apps.googleusercontent.com';
const OWNER_EMAIL = 'arhanshaikh4411@gmail.com';
const ADMIN_EMAIL = OWNER_EMAIL; // legacy alias for owner checks where needed


class Ultron {
  constructor() {
    this.isActive = false;
    this.mode = null;
    this.isListening = false;
    this.isSpeaking = false;
    this.recognition = null;
    this.orb = null;
    this.startTime = null;
    this.uptimeInterval = null;
    this.history = [];
    this.currentChatId = null;
    this.pendingFile = null;
    this.generatedFiles = [];

    this.$ = (id) => document.getElementById(id);
    this.on = (id, event, fn) => { const el = this.$(id); if (el) el[event] = fn; };
    this.chatLog = this.$('chatLog');
    this.orbGlow = this.$('orbGlow');
    this.waveRings = this.$('waveRings');

    try { this.initOrb(); } catch (e) { console.error(e); }
    try { this.bindUpdateModal(); } catch (e) { console.error(e); }
    try { this.bindInformation(); } catch (e) { console.error(e); }
    try { this.checkForUpdate(); } catch (e) { console.error(e); }
    try { this.initSpeech(); } catch (e) { console.error(e); }
    try { this.bindUI(); } catch (e) { console.error(e); }
    try { this.initGoogleSignIn(); } catch (e) { console.error(e); }
    try { this.loadUserCount(); } catch (e) {}
    try { this.ensureChat(); } catch (e) {}
    try { this.refreshLimitDisplay(); } catch (e) {}
    try { this.loadTheme(); } catch (e) {}
    try { this.loadUiStyle(); } catch (e) {}
    try { this.maybeShowInfoFirstVisit(); } catch (e) {}
    try { this.refreshInboxDot && this.refreshInboxDot(); } catch (e) {}
  }

  initGoogleSignIn() {
    if (!GOOGLE_CLIENT_ID || GOOGLE_CLIENT_ID.includes('PLACEHOLDER')) {
      return;
    }
    // set data-client_id on onload div
    const onload = document.getElementById('g_id_onload');
    if (onload) onload.setAttribute('data-client_id', GOOGLE_CLIENT_ID);
    const tryRender = () => {
      if (window.google && google.accounts && google.accounts.id) {
        google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: window.ultronGoogleCallback,
          auto_select: false,
          cancel_on_tap_outside: true
        });
        const host = document.querySelector('.g_id_signin');
        if (host) {
          google.accounts.id.renderButton(host, {
            type: 'standard',
            theme: 'outline',
            size: 'large',
            text: 'signin_with',
            shape: 'rectangular',
            width: 280
          });
        }
      } else {
        setTimeout(tryRender, 400);
      }
    };
    tryRender();
  }

  parseJwt(token) {
    try {
      const base = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      const json = decodeURIComponent(atob(base).split('').map(c =>
        '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)
      ).join(''));
      return JSON.parse(json);
    } catch (e) {
      return null;
    }
  }

  handleGoogleCredential(credential) {
    const payload = this.parseJwt(credential);
    if (!payload || !payload.email) {
      alert('Google sign-in did not return an email.');
      return;
    }
    const email = String(payload.email).toLowerCase();
    const name = payload.name || '';
    const pic = payload.picture || '';
    localStorage.setItem('ultron_email', email);
    localStorage.setItem('ultron_name', name);
    localStorage.setItem('ultron_auth', 'google');
    localStorage.removeItem('ultron_pass');
    if (pic) localStorage.setItem('ultron_pic', pic);
    else localStorage.removeItem('ultron_pic');

    let emails = [];
    try { emails = JSON.parse(localStorage.getItem('ultron_emails') || '[]'); } catch (e) {}
    if (!emails.includes(email)) {
      emails.push(email);
      localStorage.setItem('ultron_emails', JSON.stringify(emails));
    }
    this.saveAccountState('guest');
    this.tryRestoreDeleted(email);
    this.loadAccountState(email);
    this.registerUserOnServer(email);
    this.fetchRole(email);
    // 24h soft-delete recovery
    try {
      const delAt = parseInt(localStorage.getItem('ultron_deleted_' + email) || '0', 10);
      if (delAt && Date.now() - delAt > 86400000) {
        localStorage.removeItem(this.accountKey(email));
        localStorage.removeItem('ultron_deleted_' + email);
      } else if (delAt) {
        localStorage.removeItem('ultron_deleted_' + email);
      }
    } catch (e) {}
    this.switchAccountStorage(email);
    this.refreshInboxDot();
    // detect admin role via status
    this.adminApi('status', email).then(data => {
      const ans = String(data.answer || data.status || '');
      if (ans.includes('admin')) localStorage.setItem('ultron_is_admin', '1');
      else if (email !== OWNER_EMAIL) localStorage.removeItem('ultron_is_admin');
    }).catch(() => {});
    const modal = this.$('loginModal');
    if (modal) modal.classList.add('hidden');
    this.addLog('system', 'GOOGLE LOGIN: ' + email);
    this.refreshInbox();
    this.openProfile();
  }




  async checkForUpdate() {
    try {
      const res = await fetch('/version.json?t=' + Date.now(), { cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      const remote = String(data.version || '');
      if (!remote) return;
      const ignored = localStorage.getItem('ultron_ignore_version') || '';
      const seen = localStorage.getItem('ultron_seen_version') || '';
      if (remote === ignored) return;
      // First visit: store version, no popup
      if (!seen) {
        localStorage.setItem('ultron_seen_version', remote);
        return;
      }
      if (remote === seen) return;
      // New version vs what this device last used
      const msg = this.$('updateMessage');
      const ver = this.$('updateVersion');
      if (msg) msg.textContent = data.message || 'A new version of Ultron.exe is available.';
      if (ver) ver.textContent = remote;
      const modal = this.$('updateModal');
      if (modal) modal.classList.remove('hidden');
      this._pendingVersion = remote;
      this._pendingApk = data.apkUrl || '/Ultron-exe.apk';
    } catch (e) {}
  }

  bindUpdateModal() {
    const close = () => {
      const modal = this.$('updateModal');
      if (modal) modal.classList.add('hidden');
    };
    const on = (id, fn) => { const el = this.$(id); if (el) el.onclick = fn; };
    on('updateContinueBtn', () => {
      if (this._pendingVersion) localStorage.setItem('ultron_seen_version', this._pendingVersion);
      close();
    });
    on('updateIgnoreBtn', () => {
      if (this._pendingVersion) {
        localStorage.setItem('ultron_ignore_version', this._pendingVersion);
        localStorage.setItem('ultron_seen_version', this._pendingVersion);
      }
      close();
    });
    on('updateDownloadBtn', () => {
      const url = this._pendingApk || '/Ultron-exe.apk';
      window.location.href = url;
      if (this._pendingVersion) localStorage.setItem('ultron_seen_version', this._pendingVersion);
      close();
    });
  }



  bindInformation() {
    const scroll = this.$('infoScroll');
    const accept = this.$('infoAcceptBtn');
    const decline = this.$('infoDeclineBtn');
    const unlock = () => {
      if (accept) accept.disabled = false;
      if (decline) decline.disabled = false;
    };
    if (scroll) {
      scroll.addEventListener('scroll', () => {
        if (scroll.scrollTop + scroll.clientHeight >= scroll.scrollHeight - 16) unlock();
      }, { passive: true });
    }
    // safety: never trap the user forever
    setTimeout(unlock, 4000);
    const click = (id, fn) => {
      const el = this.$(id);
      if (!el) return;
      el.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        fn();
      });
    };
    click('infoAcceptBtn', () => this.closeInfoModal(true));
    click('infoDeclineBtn', () => this.closeInfoModal(false));
    click('infoCloseBtn', () => this.closeInfoModal(true));
    click('inboxClose', () => {
      const m = this.$('inboxModal');
      if (m) m.classList.add('hidden');
    });
  }


  openInfoModal(fromMenu) {
    const modal = this.$('infoModal');
    if (!modal) return;
    const accept = this.$('infoAcceptBtn');
    const decline = this.$('infoDeclineBtn');
    const closeBtn = this.$('infoCloseBtn');
    const scroll = this.$('infoScroll');
    if (fromMenu) {
      if (accept) { accept.classList.add('hidden'); accept.disabled = false; }
      if (decline) { decline.classList.add('hidden'); decline.disabled = false; }
      if (closeBtn) closeBtn.classList.remove('hidden');
    } else {
      if (accept) { accept.classList.remove('hidden'); accept.disabled = true; }
      if (decline) { decline.classList.remove('hidden'); decline.disabled = true; }
      if (closeBtn) closeBtn.classList.add('hidden');
      if (scroll) scroll.scrollTop = 0;
      setTimeout(() => {
        if (accept) accept.disabled = false;
        if (decline) decline.disabled = false;
      }, 4000);
    }
    modal.classList.remove('hidden');
  }



  // ---- account snapshots (guest vs gmail) ----
  stateKey(email) {
    return 'ultron_state_' + (email || 'guest');
  }
  saveAccountState(email) {
    const key = this.stateKey(email || 'guest');
    const data = {
      history: this.history,
      currentChatId: this.currentChatId,
      chats: this.getChats(),
      memory: localStorage.getItem('ultron_memory') || '',
      savedAt: Date.now()
    };
    try { localStorage.setItem(key, JSON.stringify(data)); } catch (e) {}
  }
  loadAccountState(email) {
    const key = this.stateKey(email || 'guest');
    try {
      const raw = localStorage.getItem(key);
      if (!raw) {
        this.history = [];
        this.currentChatId = null;
        this.ensureChat();
        return;
      }
      const data = JSON.parse(raw);
      if (data.chats) this.saveChats(data.chats);
      this.history = data.history || [];
      this.currentChatId = data.currentChatId || null;
      if (data.memory != null) localStorage.setItem('ultron_memory', data.memory);
      if (this.chatLog) {
        this.chatLog.innerHTML = '';
        (this.history || []).forEach(h => this.addLog(h.role === 'user' ? 'user' : 'ultron', h.text, true));
      }
    } catch (e) {}
  }
  // delete account: soft-delete 24h
  softDeleteAccount(email) {
    if (!email) return;
    const snap = localStorage.getItem(this.stateKey(email));
    const payload = { deletedAt: Date.now(), state: snap };
    try { localStorage.setItem('ultron_deleted_' + email, JSON.stringify(payload)); } catch (e) {}
    localStorage.removeItem(this.stateKey(email));
  }
  tryRestoreDeleted(email) {
    try {
      const raw = localStorage.getItem('ultron_deleted_' + email);
      if (!raw) return false;
      const payload = JSON.parse(raw);
      const age = Date.now() - (payload.deletedAt || 0);
      if (age < 86400000 && payload.state) {
        localStorage.setItem(this.stateKey(email), payload.state);
        localStorage.removeItem('ultron_deleted_' + email);
        return true;
      }
      localStorage.removeItem('ultron_deleted_' + email);
    } catch (e) {}
    return false;
  }

  async refreshInbox() {
    const dot = this.$('inboxDot');
    const list = this.$('inboxList');
    try {
      const data = await this.askWorkerRaw('inbox', { action: 'inbox_get' });
      const items = data.items || [];
      let hasRed = false, hasYellow = false;
      items.forEach(it => {
        if (it.color === 'red') hasRed = true;
        if (it.color === 'yellow') hasYellow = true;
      });
      if (dot) {
        dot.classList.remove('hidden', 'red', 'yellow');
        if (hasRed) dot.classList.add('red');
        else if (hasYellow) dot.classList.add('yellow');
        else dot.classList.add('hidden');
      }
      if (list) {
        if (!items.length) list.innerHTML = '<p class="modal-note">No messages</p>';
        else list.innerHTML = items.map(it =>
          '<div class="inbox-item ' + (it.color || '') + '"><strong>' + this.escape(it.from || '') +
          '</strong><div>' + this.escape(it.text || '') + '</div></div>'
        ).join('');
      }
    } catch (e) {
      if (dot) dot.classList.add('hidden');
    }
  }

  openInbox() {
    const m = this.$('inboxModal');
    if (m) m.classList.remove('hidden');
    this.refreshInbox();
  }



  closeInfoModal(accepted) {
    const modal = this.$('infoModal');
    if (modal) modal.classList.add('hidden');
    localStorage.setItem('ultron_info_seen', '1');
    localStorage.setItem('ultron_info_choice', accepted ? 'accept' : 'decline');
  }


  openInfo(fromMenu) { this.openInformation(!!fromMenu); }
  closeInfo() { this.closeInfoModal(true); }
  bindInfoModal() { this.bindInformation(); }
  maybeShowFirstInfo() { this.maybeShowInfoFirstVisit(); }

  maybeShowInfoFirstVisit() {
    if (localStorage.getItem('ultron_info_seen') === '1') return;
    setTimeout(() => this.openInfoModal(false), 500);
  }


  initOrb() {
    try { if (this.orb && this.orb.destroy) this.orb.destroy(); } catch (e) {}
    const s = localStorage.getItem('ultron_ui_style') || '1';
    try {
      this.orb = (s === '2') ? new UltronOrbSolar('orbCanvas') : new UltronOrbClassic('orbCanvas');
    } catch (e) {
      console.error(e);
      try { this.orb = new UltronOrbClassic('orbCanvas'); } catch (e2) { this.orb = null; }
    }
  }

  initSpeech() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    this.recognition = new SR();
    this.recognition.continuous = true;
    this.recognition.interimResults = false;
    this.recognition.lang = 'en-US';
    this.recognition.onstart = () => {
      this.isListening = true;
      const mic = this.$('micBtn');
      if (mic) mic.classList.add('listening');
      if (this.orb) this.orb.setListening(true);
      this.updateStatus();
    };
    this.recognition.onend = () => {
      this.isListening = false;
      const mic = this.$('micBtn');
      if (mic) mic.classList.remove('listening');
      if (this.orb) this.orb.setListening(false);
      this.updateStatus();
      if (this.isActive && this.mode === 'voice' && !this.isSpeaking) {
        try { this.recognition.start(); } catch (e) {}
      }
    };
    this.recognition.onerror = () => {
      this.isListening = false;
      const mic = this.$('micBtn');
      if (mic) mic.classList.remove('listening');
      if (this.orb) this.orb.setListening(false);
    };
    this.recognition.onresult = (event) => {
      const last = event.results[event.results.length - 1];
      if (!last || !last.isFinal) return;
      const text = (last[0] && last[0].transcript || '').trim();
      if (text) {
        this.addLog('user', text);
        this.handleMessage(text);
      }
    };
  }

  loadUiStyle() {
    const s = localStorage.getItem('ultron_ui_style') || '1';
    document.querySelectorAll('.style-card').forEach(btn => {
      if (btn.getAttribute('data-style') === String(s)) btn.classList.add('active');
      else btn.classList.remove('active');
    });
    // orb already created in initOrb with same style — only rebuild if mismatch
  }

  applyUiStyle(style) {
    try {
      style = String(style || '1');
      if (style !== '1' && style !== '2') style = '1';
      localStorage.setItem('ultron_ui_style', style);
      document.querySelectorAll('.style-card').forEach(btn => {
        if (btn.getAttribute('data-style') === style) btn.classList.add('active');
        else btn.classList.remove('active');
      });
      try { if (this.orb && this.orb.destroy) this.orb.destroy(); } catch (e) {}
      try {
        this.orb = (style === '2') ? new UltronOrbSolar('orbCanvas') : new UltronOrbClassic('orbCanvas');
        if (this.orb) {
          try { this.orb.setSpeaking(!!this.isSpeaking); } catch (e) {}
          try { this.orb.setListening(!!this.isListening); } catch (e) {}
        }
      } catch (e) { console.error(e); }
      const w = this.$('hudModal');
      if (w) w.classList.add('hidden');
    } catch (e) {
      console.error('applyUiStyle', e);
    }
  }

  markStyleActive(style) {
    document.querySelectorAll('.style-card').forEach(btn => {
      if (btn.getAttribute('data-style') === String(style)) btn.classList.add('active');
      else btn.classList.remove('active');
    });
  }

  cycleLang() {
    const langs = [
      { code: 'en-US', label: 'English' },
      { code: 'hi-IN', label: 'Hindi' },
      { code: 'es-ES', label: 'Spanish' },
      { code: 'ar-SA', label: 'Arabic' }
    ];
    const cur = langs.findIndex(l => l.code === (this.recognition?.lang || 'en-US'));
    const next = langs[(cur + 1) % langs.length];
    if (this.recognition) this.recognition.lang = next.code;
    this.$('langBtn').textContent = 'Language: ' + next.label;
    this.addLog('system', 'LANGUAGE: ' + next.label);
  }


  extractFilesFromText(text) {
    if (!text) return;
    const re = /```([\w.+-]*)\n([\s\S]*?)```/g;
    let m;
    let idx = 0;
    while ((m = re.exec(text)) !== null) {
      idx++;
      const lang = (m[1] || 'txt').toLowerCase();
      const body = (m[2] || '').trim();
      if (!body) continue;
      const extMap = {
        javascript: 'js', js: 'js', typescript: 'ts', ts: 'ts', python: 'py', py: 'py',
        html: 'html', css: 'css', json: 'json', java: 'java', c: 'c', cpp: 'cpp',
        go: 'go', rust: 'rs', php: 'php', sql: 'sql', bash: 'sh', shell: 'sh', sh: 'sh',
        xml: 'xml', yaml: 'yml', yml: 'yml', markdown: 'md', md: 'md', text: 'txt', txt: 'txt'
      };
      const ext = extMap[lang] || (lang && lang.length <= 6 ? lang : 'txt');
      const name = 'ultron-' + Date.now() + '-' + idx + '.' + ext;
      this.generatedFiles.push({ name: name, content: body, lang: lang || 'text' });
    }
    if (this.generatedFiles.length > 30) this.generatedFiles = this.generatedFiles.slice(-30);
  }

  openFiles() {
    const list = this.$('filesList');
    if (!list) return;
    list.innerHTML = '';
    (this.history || []).forEach(h => {
      if (h.role === 'ultron') this.extractFilesFromText(h.text);
    });
    const seen = new Set();
    const files = [];
    for (let i = this.generatedFiles.length - 1; i >= 0; i--) {
      const f = this.generatedFiles[i];
      const key = f.content.slice(0, 60);
      if (seen.has(key)) continue;
      seen.add(key);
      files.push(f);
      if (files.length >= 20) break;
    }
    files.reverse();
    if (!files.length) {
      list.innerHTML = '<p class="modal-note">No files yet. Ask Ultron for code (example: write a python hello world) and open Files again.</p>';
    } else {
      files.forEach((f, i) => {
        const item = document.createElement('div');
        item.className = 'file-item';
        const preview = f.content.slice(0, 120).replace(/</g, '&lt;');
        item.innerHTML =
          '<div class="file-name">' + f.name + '</div>' +
          '<div class="file-preview">' + preview + (f.content.length > 120 ? '…' : '') + '</div>' +
          '<div class="file-actions">' +
          '<button type="button" data-act="download" data-i="' + i + '">Save</button>' +
          '<button type="button" data-act="copy" data-i="' + i + '">Copy</button>' +
          '<button type="button" data-act="share" data-i="' + i + '">Share</button>' +
          '</div>';
        list.appendChild(item);
      });
      list.querySelectorAll('button').forEach(btn => {
        btn.onclick = () => {
          const i = parseInt(btn.getAttribute('data-i'), 10);
          const act = btn.getAttribute('data-act');
          const file = files[i];
          if (!file) return;
          if (act === 'download') this.downloadFile(file);
          else if (act === 'copy') this.copyFile(file);
          else if (act === 'share') this.shareFile(file);
        };
      });
    }
    this.$('filesModal').classList.remove('hidden');
  }

  downloadFile(file) {
    try {
      const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      this.addLog('system', 'SAVED: ' + file.name);
    } catch (e) {
      this.addLog('system', 'Save failed.');
    }
  }

  async copyFile(file) {
    try {
      await navigator.clipboard.writeText(file.content);
      this.addLog('system', 'COPIED: ' + file.name);
    } catch (e) {
      this.addLog('system', 'Copy failed.');
    }
  }

  async shareFile(file) {
    try {
      if (navigator.share) {
        const blob = new Blob([file.content], { type: 'text/plain' });
        const f = new File([blob], file.name, { type: 'text/plain' });
        try {
          if (navigator.canShare && navigator.canShare({ files: [f] })) {
            await navigator.share({ files: [f], title: file.name });
          } else {
            await navigator.share({ title: file.name, text: file.content });
          }
        } catch (e) {
          await navigator.share({ title: file.name, text: file.content });
        }
        this.addLog('system', 'SHARED: ' + file.name);
      } else {
        await this.copyFile(file);
        this.addLog('system', 'Share not supported — copied instead.');
      }
    } catch (e) {
      if (e && e.name === 'AbortError') return;
      this.addLog('system', 'Share cancelled or failed.');
    }
  }

  // ----- ACTIVATE FLOW -----
  onActivate() {
    this.isActive = true;
    this.startTime = Date.now();
    this.startUptime();
    const ab = this.$('activateBtn');
    const db = this.$('deactivateBtn');
    if (ab) ab.classList.add('hidden');
    if (db) db.classList.remove('hidden');
    const welcome = this.$('welcomeCard');
    if (welcome) welcome.classList.add('hidden');
    // single flow: choose voice or chat
    const modeSel = this.$('modeSelect');
    if (modeSel) modeSel.classList.remove('hidden');
    this.addLog('system', 'CHOOSE VOICE OR CHAT.');
    this.updateStatus();
  }


  setMode(mode) {
    this.mode = mode;
    this.$('modeStatus').textContent = mode.toUpperCase();
    const ms = this.$('modeSelect');
    if (ms) ms.classList.add('hidden');
    if (mode === 'voice') {
      // Style 2 voice: listen; also show input+mic for flexibility
      this.$('chatInputBar').classList.remove('hidden');
      const mic = this.$('micBtn');
      if (mic) mic.classList.add('listening');
      this.startListening();
      this.addLog('system', 'VOICE ONLINE.');
      this.speak('Online.');
    } else {
      this.$('chatInputBar').classList.remove('hidden');
      this.stopMic();
      const mic = this.$('micBtn');
      if (mic) mic.classList.remove('listening');
      this.addLog('system', 'CHAT ONLINE.');
    }
    this.updateStatus();
  }

  fullDeactivate() {
    this.isActive = false;
    this.mode = null;
    this.stopMic();
    window.speechSynthesis.cancel();
    this.isSpeaking = false;
    this.orb.setActive(false);
    this.orb.setSpeaking(false);
    this.orbGlow.classList.remove('active', 'speaking');
    this.waveRings.classList.remove('active');
    this.$('activateBtn').classList.remove('hidden');
    this.$('deactivateBtn').classList.add('hidden');
    const welcome = this.$('welcomeCard');
    if (welcome) welcome.classList.remove('hidden');
    const mic = this.$('micBtn');
    if (mic) mic.classList.remove('listening');
    const modeSelect = this.$('modeSelect'); if (modeSelect) modeSelect.classList.add('hidden');
    this.$('chatInputBar').classList.add('hidden');
    this.$('modeStatus').textContent = 'NONE';
    this.stopUptime();
    this.persistCurrentChat();
    this.addLog('system', 'SYSTEM OFFLINE.');
    this.updateStatus();
  }

  stopMic() {
    this.isListening = false;
    if (this.recognition) { try { this.recognition.abort(); this.recognition.stop(); } catch (e) {} }
  }
  startListening() {
    if (this.mode !== 'voice' || !this.recognition) return;
    try { this.recognition.start(); } catch (e) {}
  }
  restartListening() {
    if (this.mode !== 'voice') return;
    setTimeout(() => {
      if (this.mode === 'voice' && this.isActive && !this.isSpeaking) {
        try { this.recognition.start(); } catch (e) {}
      }
    }, 400);
  }

  // ----- MESSAGES -----
  sendChat() {
    const input = this.$('chatInput');
    const text = input.value.trim();
    if (!text && !this.pendingFile) return;
    input.value = '';
    if (text) this.addLog('user', text);
    this.handleMessage(text || 'Look at the uploaded file and respond.');
  }

  async handleMessage(text) {
    // Slash commands: public for everyone, admin-only for owner
    if (String(text || '').trim().startsWith('/')) {
      let cmdReply = await this.tryPublicCommand(text);
      if (!cmdReply) cmdReply = await this.tryAdminCommand(text);
      if (cmdReply) {
        this.pushHistory('user', text);
        this.pushHistory('ultron', cmdReply);
        this.addLog('ultron', cmdReply);
        if (this.mode === 'voice') this.speak(cmdReply);
        this.persistCurrentChat();
        return;
      }
    }

    const lower = (text || '').toLowerCase();

    // Creator only when asked
    if (/who (made|created|built) (you|ultron)|your creator|who is your creator|who made (you|ultron)|who created ultron|who is (the )?creator|made by whom|your maker|who developed (you|ultron)/.test(lower)) {
      const r = 'I was created by Arhan Shaikh.';
      this.pushHistory('user', text);
      this.pushHistory('ultron', r);
      this.addLog('ultron', r);
      if (this.mode === 'voice') this.speak(r);
      this.persistCurrentChat();
      return;
    }

    // Open links
    if (/^open\s+https?:\/\//i.test(text)) {
      const url = text.replace(/^open\s+/i, '').trim();
      window.open(url, '_blank');
      const r = 'Opening link.';
      this.pushHistory('user', text);
      this.pushHistory('ultron', r);
      this.addLog('ultron', r);
      this.persistCurrentChat();
      return;
    }

    const local = this.localReply(lower);
    if (local) {
      this.pushHistory('user', text);
      this.pushHistory('ultron', local);
      this.addLog('ultron', local);
      if (this.mode === 'voice') this.speak(local);
      this.persistCurrentChat();
      return;
    }

    // Limit check (monetization)
    if (!this.isProUser() && this.getRemaining() <= 0) {
      this.addLog('ultron', 'Daily limit reached (20). Try again tomorrow.');
      return;
    }

    // AI via Worker
    this.addLog('system', 'THINKING...');
    try {
      let answer = await this.askWorker(text);
      answer = this.cleanReply(answer);
      this.pushHistory('user', text);
      this.pushHistory('ultron', answer);
      this.addLog('ultron', answer);
      this.extractFilesFromText(answer);

      if (this.mode === 'voice') this.speak(answer);
      this.bumpLocalLimit();
    } catch (err) {
      this.addLog('ultron', 'Could not reach Ultron. Try again.');
    }
    this.persistCurrentChat();
  }


  formatLists(text) {
    if (!text) return text;
    let t = String(text);
    // remove leftover markdown stars
    t = t.replace(/\*\*/g, '').replace(/\*/g, '');
    // force newline before 2) 3) 4)... when stuck on same line
    t = t.replace(/\s*(?=[2-9]\)|[1-9][0-9]\))/g, '\n');
    // also 1) at start of sentence mid-line after period
    t = t.replace(/([.:;])\s*(1\))/g, '$1\n$2');
    // collapse too many blank lines
    t = t.replace(/\n{3,}/g, '\n\n').trim();
    return t;
  }

  localReply(lower) {
    if (/(hello|hi|hey)\b/.test(lower)) return 'Hello. How can I help?';
    if (/(time|what time)/.test(lower)) return 'Current time is ' + new Date().toLocaleTimeString() + '.';
    if (/(date|today)/.test(lower)) return 'Today is ' + new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) + '.';
    if (/(thank)/.test(lower)) return "You're welcome.";
    if (/(joke)/.test(lower)) return 'Peace was never an option. Neither was this joke.';
    
    if (/(goodbye|bye|deactivate)/.test(lower)) {
      setTimeout(() => this.fullDeactivate(), 1400);
      return 'Deactivating.';
    }
    return null;
  }

  pushHistory(role, text) {
    this.history.push({ role: role, text: text });
    if (this.history.length > 40) this.history = this.history.slice(-40);
  }

  async askWorker(text, extra) {
    const data = await this.askWorkerRaw(text, extra);
    if (data.error) return data.error;
    return data.answer || "No response.";
  }

  async requestImage() {
    const desc = window.prompt('Describe the image Ultron should create:');
    if (!desc) return;
    this.addLog('user', '[Image] ' + desc);
    this.addLog('system', 'GENERATING IMAGE...');
    try {
      const data = await this.askWorkerRaw(desc, { type: 'image' });
      if (data.image) {
        this.addLogImage(data.answer || 'Image generated.', data.image);
        this.pushHistory('user', '[Image] ' + desc);
        this.pushHistory('ultron', data.answer || '[image]');
      } else {
        const answer = data.answer || data.error || 'No image returned.';
        this.addLog('ultron', answer);
        this.pushHistory('user', '[Image] ' + desc);
        this.pushHistory('ultron', answer);
      }
      this.bumpLocalLimit();
      this.persistCurrentChat();
      if (this.mode === 'voice') this.speak('Image ready.');
    } catch (e) {
      this.addLog('ultron', 'Image generation failed.');
    }
  }

  addLogImage(text, dataUrl) {
    const el = document.createElement('div');
    el.className = 'log-entry ultron';
    el.innerHTML = '<span class="tag">ULTRON:</span>' + this.escape(text) +
      '<br><img class="ai-img" src="' + dataUrl + '" alt="ai" />';
    this.chatLog.appendChild(el);
    this.chatLog.scrollTop = this.chatLog.scrollHeight;
  }

  async askWorkerRaw(text, extra) {
    const email = localStorage.getItem('ultron_email') || 'guest';
    const memory = localStorage.getItem('ultron_memory') || '';
    const res = await fetch(WORKER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: text,
        email: email,
        history: this.history.slice(-12),
        memory: memory,
        ...(extra || {})
      })
    });
    return await res.json();
  }

  onFile(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    this.pendingFile = file;
    this.addLog('system', 'FILE: ' + file.name + '. Type what you want me to do with it.');
  }

  // ----- VOICE (deeper Ultron-like) -----
  speak(text) {
    if (this.mode !== 'voice') return;
    text = this.cleanReply(text);
    window.speechSynthesis.cancel();
    this.isSpeaking = true;
    this.orb.setSpeaking(true);
    this.orbGlow.classList.add('speaking');
    this.updateStatus();

    const u = new SpeechSynthesisUtterance(text);
    u.rate = 0.85;
    u.pitch = 0.55;
    u.volume = 1;
    const voices = speechSynthesis.getVoices();
    const deep = voices.find(v => /google uk english male|microsoft david|daniel|male/i.test(v.name))
      || voices.find(v => v.lang && v.lang.startsWith('en'));
    if (deep) u.voice = deep;

    u.onend = () => {
      this.isSpeaking = false;
      this.orb.setSpeaking(false);
      this.orbGlow.classList.remove('speaking');
      this.updateStatus();
      if (this.mode === 'voice') this.restartListening();
    };
    u.onerror = () => {
      this.isSpeaking = false;
      this.orb.setSpeaking(false);
      this.orbGlow.classList.remove('speaking');
      this.updateStatus();
    };
    if (!voices.length) speechSynthesis.onvoiceschanged = () => speechSynthesis.speak(u);
    else speechSynthesis.speak(u);
  }

  addLog(type, text, skipScroll) {
    const el = document.createElement('div');
    el.className = 'log-entry ' + type;
    if (type === 'user') el.innerHTML = '<span class="tag">USER:</span>' + this.escape(text);
    else if (type === 'ultron') el.innerHTML = '<span class="tag">ULTRON:</span>' + this.escape(text);
    else el.textContent = text;
    this.chatLog.appendChild(el);
    if (!skipScroll) this.chatLog.scrollTop = this.chatLog.scrollHeight;
  }

  escape(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\n/g, '<br>');
  }

  // Remove markdown and force readable lists (new line per item)
  cleanReply(s) {
    let t = String(s || '');
    t = t.replace(/\*\*([^*]+)\*\*/g, '$1');
    t = t.replace(/__([^_]+)__/g, '$1');
    t = t.replace(/\*([^*]+)\*/g, '$1');
    t = t.replace(/_([^_]+)_/g, '$1');
    t = t.replace(/\*+/g, '');
    t = t.replace(/`+/g, '');
    t = t.replace(/#{1,6}\s*/g, '');
    // Put each 1) 2) 3) on its own line
    t = t.replace(/\s*([1-9][0-9]?)\)\s*/g, '\n$1) ');
    t = t.replace(/\s*[-•]\s+/g, '\n- ');
    t = t.replace(/\n{3,}/g, '\n\n').trim();
    return t;
  }

  copyAiOnly() {
    const nodes = this.chatLog.querySelectorAll('.log-entry.ultron');
    let t = '';
    nodes.forEach(n => { t += n.textContent.replace('ULTRON:', '').trim() + '\n'; });
    if (!t) { this.addLog('system', 'NOTHING TO COPY.'); return; }
    navigator.clipboard.writeText(t.trim()).then(() => this.addLog('system', 'COPIED.')).catch(() => this.addLog('system', 'COPY FAILED.'));
  }

  updateStatus() {
    if (this.isActive) {
      this.$('systemStatus').textContent = 'ONLINE';
      this.$('systemStatus').className = 'value online';
      this.$('micStatus').textContent = this.isListening ? 'ON' : 'OFF';
      this.$('micStatus').className = this.isListening ? 'value listening' : 'value';
    } else {
      this.$('systemStatus').textContent = 'OFFLINE';
      this.$('systemStatus').className = 'value';
      this.$('micStatus').textContent = 'OFF';
      this.$('micStatus').className = 'value';
      this.$('uptime').textContent = '00:00';
    }
  }

  startUptime() {
    this.stopUptime();
    this.uptimeInterval = setInterval(() => {
      if (!this.startTime) return;
      const sec = Math.floor((Date.now() - this.startTime) / 1000);
      const m = String(Math.floor(sec / 60)).padStart(2, '0');
      const s = String(sec % 60).padStart(2, '0');
      this.$('uptime').textContent = m + ':' + s;
    }, 1000);
  }
  stopUptime() {
    if (this.uptimeInterval) clearInterval(this.uptimeInterval);
    this.uptimeInterval = null;
  }

  bindUI() {
    const on = (id, ev, fn) => {
      const el = this.$(id);
      if (!el) return;
      el[ev] = fn;
    };
    on('activateBtn', 'onclick', () => this.onActivate());
    on('deactivateBtn', 'onclick', () => this.fullDeactivate());
    on('newChatBtn', 'onclick', () => this.newConversation && this.newConversation());
    on('hudBtn', 'onclick', () => {
      const m = this.$('menuDropdown'); if (m) m.classList.remove('show');
      const w = this.$('hudModal'); if (w) w.classList.remove('hidden');
    });
    on('hudClose', 'onclick', () => {
      const w = this.$('hudModal'); if (w) w.classList.add('hidden');
    });
    document.querySelectorAll('.theme-card').forEach(btn => {
      btn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.applyTheme(btn.getAttribute('data-theme'));
      };
    });
    document.querySelectorAll('.style-card').forEach(btn => {
      btn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.applyUiStyle(btn.getAttribute('data-style'));
      };
    });
    on('voiceModeBtn', 'onclick', () => this.setMode('voice'));
    on('chatModeBtn', 'onclick', () => this.setMode('chat'));
    on('micBtn', 'onclick', () => this.toggleMic && this.toggleMic());

    on('menuBtn', 'onclick', (e) => {
      e.stopPropagation();
      const more = this.$('moreDropdown');
      const menu = this.$('menuDropdown');
      if (more) more.classList.remove('show');
      if (menu) menu.classList.toggle('show');
    });
    on('moreBtn', 'onclick', (e) => {
      e.stopPropagation();
      const more = this.$('moreDropdown');
      const menu = this.$('menuDropdown');
      if (menu) menu.classList.remove('show');
      if (more) more.classList.toggle('show');
    });
    document.addEventListener('click', () => {
      const more = this.$('moreDropdown');
      const menu = this.$('menuDropdown');
      if (more) more.classList.remove('show');
      if (menu) menu.classList.remove('show');
    });

    on('deleteConvBtn', 'onclick', () => {
      if (this.deleteCurrentChat) this.deleteCurrentChat();
      const m = this.$('moreDropdown'); if (m) m.classList.remove('show');
    });
    on('copyAiBtn', 'onclick', () => {
      this.copyAiOnly();
      const m = this.$('moreDropdown'); if (m) m.classList.remove('show');
    });
    on('filesBtn', 'onclick', () => {
      const m = this.$('moreDropdown'); if (m) m.classList.remove('show');
      if (this.openFiles) this.openFiles();
    });
    on('filesClose', 'onclick', () => {
      const m = this.$('filesModal'); if (m) m.classList.add('hidden');
    });

    on('profileBtn', 'onclick', () => {
      const m = this.$('menuDropdown'); if (m) m.classList.remove('show');
      this.openProfile();
    });
    on('chatsBtn', 'onclick', () => {
      const m = this.$('menuDropdown'); if (m) m.classList.remove('show');
      if (this.openChats) this.openChats();
    });
    on('memoryBtn', 'onclick', () => {
      const m = this.$('menuDropdown'); if (m) m.classList.remove('show');
      if (this.openMemory) this.openMemory();
    });
    on('infoBtn', 'onclick', () => {
      const m = this.$('menuDropdown'); if (m) m.classList.remove('show');
      this.openInformation ? this.openInformation(true) : this.openInfoModal(true);
    });
    on('inboxBtn', 'onclick', () => {
      const m = this.$('menuDropdown'); if (m) m.classList.remove('show');
      if (this.openInbox) this.openInbox();
    });
    on('downloadApkBtn', 'onclick', () => {
      const m = this.$('menuDropdown'); if (m) m.classList.remove('show');
      window.location.href = 'https://ultronexe.netlify.app/Ultron-exe.apk';
    });
    on('langBtn', 'onclick', () => {
      const m = this.$('menuDropdown'); if (m) m.classList.remove('show');
      this.cycleLang();
    });
    on('logoutBtn', 'onclick', () => this.logout());
    on('deleteAccountBtn', 'onclick', () => this.deleteAccount());
    on('loginCancel', 'onclick', () => {
      const m = this.$('loginModal'); if (m) m.classList.add('hidden');
    });
    on('closeProfileBtn', 'onclick', () => {
      const m = this.$('loginModal'); if (m) m.classList.add('hidden');
    });
    on('chatsClose', 'onclick', () => {
      const m = this.$('chatsModal'); if (m) m.classList.add('hidden');
    });
    on('memoryClose', 'onclick', () => {
      const m = this.$('memoryModal'); if (m) m.classList.add('hidden');
    });
    on('memorySave', 'onclick', () => {
      const ta = this.$('memoryInput');
      if (ta) localStorage.setItem('ultron_memory', ta.value || '');
      const m = this.$('memoryModal'); if (m) m.classList.add('hidden');
      this.addLog('system', 'MEMORY SAVED.');
    });
    on('sendBtn', 'onclick', () => this.sendChat());
    on('chatInput', 'onkeydown', (e) => { if (e.key === 'Enter') this.sendChat(); });
    on('uploadBtn', 'onclick', () => {
      const f = this.$('fileInput'); if (f) f.click();
    });
    on('fileInput', 'onchange', (e) => this.onFile(e));
    window.addEventListener('beforeunload', () => this.stopMic && this.stopMic());
  }

  openProfile() {
    const email = (localStorage.getItem('ultron_email') || '').toLowerCase();
    const loginView = this.$('loginView');
    const profileView = this.$('profileView');
    if (email) {
      if (loginView) loginView.classList.add('hidden');
      if (profileView) profileView.classList.remove('hidden');
      const em = this.$('profileEmailShow');
      if (em) em.textContent = email;
      const nameEl = this.$('profileNameShow');
      if (nameEl) nameEl.textContent = localStorage.getItem('ultron_name') || '';
      const img = this.$('profilePic');
      const pic = localStorage.getItem('ultron_pic') || '';
      if (img) {
        if (pic) { img.src = pic; img.style.display = 'block'; }
        else { img.removeAttribute('src'); img.style.display = 'none'; }
      }
      const isOwner = email === OWNER_EMAIL;
      const badge = this.$('adminBadge');
      const panel = this.$('adminPanel');
      if (badge) {
        if (isOwner || localStorage.getItem('ultron_is_admin') === '1') badge.classList.remove('hidden');
        else badge.classList.add('hidden');
      }
      if (panel) {
        if (isOwner) { panel.classList.remove('hidden'); if (this.refreshAdminUserList) this.refreshAdminUserList(); }
        else panel.classList.add('hidden');
      }
    } else {
      if (profileView) profileView.classList.add('hidden');
      if (loginView) loginView.classList.remove('hidden');
      try { this.initGoogleSignIn(); } catch (e) {}
    }
    const modal = this.$('loginModal');
    if (modal) modal.classList.remove('hidden');
  }

  logout() {
    try {
      if (this.saveAccountState) this.saveAccountState(localStorage.getItem('ultron_email') || 'guest');
    } catch (e) {}
    localStorage.removeItem('ultron_email');
    localStorage.removeItem('ultron_name');
    localStorage.removeItem('ultron_pic');
    localStorage.removeItem('ultron_auth');
    localStorage.removeItem('ultron_is_admin');
    try { if (this.loadAccountState) this.loadAccountState('guest'); } catch (e) {}
    this.addLog('system', 'LOGGED OUT.');
    const modal = this.$('loginModal');
    if (modal) modal.classList.add('hidden');
  }

  deleteAccount() {
    const email = (localStorage.getItem('ultron_email') || '').toLowerCase();
    if (!email) return;
    if (!confirm('Delete account for ' + email + '?')) return;
    try {
      if (this.softDeleteAccount) this.softDeleteAccount(email);
      else localStorage.setItem('ultron_deleted_' + email, String(Date.now()));
    } catch (e) {}
    localStorage.removeItem('ultron_email');
    localStorage.removeItem('ultron_name');
    localStorage.removeItem('ultron_pic');
    localStorage.removeItem('ultron_auth');
    try { if (this.loadAccountState) this.loadAccountState('guest'); } catch (e) {}
    this.addLog('system', 'ACCOUNT DELETED.');
    const modal = this.$('loginModal');
    if (modal) modal.classList.add('hidden');
  }

  isAdmin() {
    const e = (localStorage.getItem('ultron_email') || '').toLowerCase();
    return e === OWNER_EMAIL || localStorage.getItem('ultron_is_admin') === '1';
  }

  isProUser() {
    const email = (localStorage.getItem('ultron_email') || '').toLowerCase();
    if (email === OWNER_EMAIL) return true;
    if (localStorage.getItem('ultron_unlimited_' + email) === '1') return true;
    return false;
  }

  getRemaining() {
    if (this.isProUser()) return 999;
    const email = (localStorage.getItem('ultron_email') || 'guest').toLowerCase();
    const day = new Date().toISOString().slice(0, 10);
    const key = 'ultron_lim_' + email + '_' + day;
    const used = parseInt(localStorage.getItem(key) || '0', 10);
    return Math.max(0, FREE_DAILY_LIMIT - used);
  }

  refreshLimitDisplay() {
    const el = this.$('limitStatus');
    if (!el) return;
    if (this.isProUser()) el.textContent = '∞';
    else el.textContent = String(this.getRemaining());
  }

  loadUserCount() {
    // Finicounter fills #finicount_views — do not overwrite
  }

  ensureChat() {
    try {
      const chats = this.getChats();
      const ids = Object.keys(chats);
      if (!ids.length) {
        const id = 'c' + Date.now();
        chats[id] = { title: 'New chat', messages: [], updated: Date.now() };
        this.saveChats(chats);
        this.currentChatId = id;
        this.history = [];
      } else {
        this.currentChatId = ids.sort((a, b) => chats[b].updated - chats[a].updated)[0];
        this.history = chats[this.currentChatId].messages || [];
      }
    } catch (e) {
      this.currentChatId = 'c' + Date.now();
      this.history = [];
    }
  }

  getChats() {
    try { return JSON.parse(localStorage.getItem('ultron_chats') || '{}'); } catch (e) { return {}; }
  }
  saveChats(chats) {
    try { localStorage.setItem('ultron_chats', JSON.stringify(chats)); } catch (e) {}
  }

  persistCurrentChat() {
    try {
      const chats = this.getChats();
      if (!this.currentChatId) this.currentChatId = 'c' + Date.now();
      chats[this.currentChatId] = {
        title: (this.history[0] && this.history[0].text || 'Chat').slice(0, 40),
        messages: this.history,
        updated: Date.now()
      };
      this.saveChats(chats);
    } catch (e) {}
  }

  newConversation() {
    this.persistCurrentChat();
    const id = 'c' + Date.now();
    const chats = this.getChats();
    chats[id] = { title: 'New chat', messages: [], updated: Date.now() };
    this.saveChats(chats);
    this.currentChatId = id;
    this.history = [];
    if (this.chatLog) this.chatLog.innerHTML = '';
    this.addLog('system', 'NEW CONVERSATION.');
  }

  deleteCurrentChat() {
    const chats = this.getChats();
    if (this.currentChatId && chats[this.currentChatId]) delete chats[this.currentChatId];
    this.saveChats(chats);
    this.history = [];
    this.currentChatId = null;
    if (this.chatLog) this.chatLog.innerHTML = '';
    this.ensureChat();
    this.addLog('system', 'CONVERSATION DELETED.');
  }

  openChats() {
    const modal = this.$('chatsModal');
    const list = this.$('chatsList');
    if (!modal || !list) return;
    const chats = this.getChats();
    const ids = Object.keys(chats).sort((a, b) => chats[b].updated - chats[a].updated);
    list.innerHTML = ids.map(id => {
      const t = this.escape((chats[id].title || id));
      return '<button type="button" class="dropdown-item chat-item" data-id="' + id + '">' + t + '</button>';
    }).join('') || '<p class="modal-note">No saved chats</p>';
    list.querySelectorAll('.chat-item').forEach(btn => {
      btn.onclick = () => {
        this.persistCurrentChat();
        this.currentChatId = btn.getAttribute('data-id');
        this.history = (chats[this.currentChatId] && chats[this.currentChatId].messages) || [];
        if (this.chatLog) {
          this.chatLog.innerHTML = '';
          this.history.forEach(m => this.addLog(m.role === 'ultron' ? 'ultron' : 'user', m.text));
        }
        modal.classList.add('hidden');
      };
    });
    modal.classList.remove('hidden');
  }

  openMemory() {
    const modal = this.$('memoryModal');
    const ta = this.$('memoryInput');
    if (ta) ta.value = localStorage.getItem('ultron_memory') || '';
    if (modal) modal.classList.remove('hidden');
  }

  applyTheme(theme) {
    if (!theme) return;
    localStorage.setItem('ultron_theme', theme);
    document.body.className = document.body.className.replace(/theme-\w+/g, '').trim();
    document.body.classList.add('theme-' + theme);
    const w = this.$('hudModal');
    if (w) w.classList.add('hidden');
  }

  loadTheme() {
    const t = localStorage.getItem('ultron_theme') || 'light';
    this.applyTheme(t);
  }

  toggleMic() {
    if (!this.isActive) {
      this.addLog('system', 'Press ACTIVATE first.');
      return;
    }
    if (this.isListening) this.stopMic();
    else this.startListening();
  }

  async tryAdminCommand(text) {
    const email = (localStorage.getItem('ultron_email') || '').toLowerCase();
    if (!email || email === 'guest') return null;
    const raw = (text || '').trim();
    if (!raw.startsWith('/')) return null;
    const isOwner = email === OWNER_EMAIL;
    const isStaffAdmin = localStorage.getItem('ultron_is_admin') === '1';
    if (!isOwner && !isStaffAdmin) return null;

    let m;
    if (isOwner) {
      m = raw.match(/^\/make\s+admin\s+(\S+@\S+)\s*$/i);
      if (m) { await this.adminApi('make_admin', m[1].toLowerCase()); return 'Owner: admin granted to ' + m[1].toLowerCase(); }
      m = raw.match(/^\/remove\s+admin\s+(\S+@\S+)\s*$/i);
      if (m) {
        if (m[1].toLowerCase() === OWNER_EMAIL) return 'Owner cannot be removed.';
        await this.adminApi('remove_admin', m[1].toLowerCase());
        return 'Owner: admin removed from ' + m[1].toLowerCase();
      }
      if (/^\/admins\s*$/i.test(raw)) {
        const data = await this.adminApi('list_admins');
        const list = data.users || data.answer || [];
        return 'Admins: ' + (Array.isArray(list) ? (list.join(', ') || '(none)') : String(list));
      }
      m = raw.match(/^\/(?:broadcast|announce)\s+(.+)$/i);
      if (m) { await this.adminApi('broadcast', 'global', m[1]); return 'Owner: broadcast sent (yellow inbox).'; }
    }

    if (/^\/give\s+no\s+limit\s*$/i.test(raw)) {
      await this.adminApi('unlimited_self');
      localStorage.setItem('ultron_unlimited_' + email, '1');
      this.refreshLimitDisplay();
      return 'No daily limit for you.';
    }
    if (/^\/remove\s+no\s+limit\s*$/i.test(raw)) {
      await this.adminApi('remove_unlimited_self');
      localStorage.removeItem('ultron_unlimited_' + email);
      this.refreshLimitDisplay();
      return 'Unlimited removed.';
    }
    if (/^\/reset\s+limit\s*$/i.test(raw)) {
      await this.adminApi('reset_self');
      return 'Your daily counter was reset.';
    }
    m = raw.match(/^\/(\S+@\S+)\s+give\s+no\s+limit\s*$/i);
    if (m) {
      const t = m[1].toLowerCase();
      if (!isOwner && t !== email) return 'No access — admins can only change their own limit.';
      await this.adminApi(t === email ? 'unlimited_self' : 'unlimited', t === email ? '' : t);
      localStorage.setItem('ultron_unlimited_' + t, '1');
      return 'No limit set for ' + t;
    }
    m = raw.match(/^\/(\S+@\S+)\s+remove\s+no\s+limit\s*$/i) || raw.match(/^\/remove\s+no\s+limit\s+(\S+@\S+)\s*$/i);
    if (m) {
      const t = m[1].toLowerCase();
      if (!isOwner && t !== email) return 'No access.';
      await this.adminApi(t === email ? 'remove_unlimited_self' : 'remove_unlimited', t === email ? '' : t);
      localStorage.removeItem('ultron_unlimited_' + t);
      return 'Unlimited removed for ' + t;
    }
    m = raw.match(/^\/ban\s+(\S+@\S+)\s*$/i);
    if (m) {
      if (!isOwner) return 'No access — only owner can ban.';
      await this.adminApi('ban', m[1].toLowerCase());
      return 'Banned ' + m[1].toLowerCase();
    }
    m = raw.match(/^\/unban\s+(\S+@\S+)\s*$/i);
    if (m) {
      if (!isOwner) return 'No access.';
      await this.adminApi('unban', m[1].toLowerCase());
      return 'Unbanned ' + m[1].toLowerCase();
    }
    m = raw.match(/^\/reset\s+(\S+@\S+)\s*$/i);
    if (m) {
      const t = m[1].toLowerCase();
      if (!isOwner && t !== email) return 'No access.';
      await this.adminApi('reset', t);
      return 'Reset for ' + t;
    }
    m = raw.match(/^\/status\s+(\S+@\S+)\s*$/i);
    if (m) {
      if (!isOwner) return 'No access.';
      const data = await this.adminApi('status', m[1].toLowerCase());
      return 'Status: ' + (data.answer || data.status || JSON.stringify(data));
    }
    m = raw.match(/^\/message\s+(\S+@\S+)\s+(.+)$/i);
    if (m) {
      const to = m[1].toLowerCase();
      if (!isOwner && to !== OWNER_EMAIL) return 'No access — admins can only message the owner.';
      await this.adminApi('message', to, m[2]);
      return 'Message sent to ' + to + ' (red inbox).';
    }
    if (/^\/users\s*$/i.test(raw)) {
      if (!isOwner) return 'No access — only owner can list users.';
      if (this.refreshAdminUserList) await this.refreshAdminUserList();
      return 'User list refreshed in Profile.';
    }
    if (/^\/help\s*$/i.test(raw)) {
      if (isOwner) {
        return 'Owner: /Make admin email, /Remove admin email, /admins, /broadcast text, /Ban, /Unban, /Status email, /Message email text, /email Give no limit, /email Remove no limit, /users, /give no limit, /remove no limit, /Reset limit';
      }
      return 'Admin: /give no limit, /remove no limit, /Reset limit, /Message ' + OWNER_EMAIL + ' text';
    }
    return null;
  }

  async adminApi(op, target, message) {
    return this.askWorkerRaw('admin', {
      action: 'admin',
      op,
      target: target || '',
      message: message || '',
      adminEmail: OWNER_EMAIL,
      email: localStorage.getItem('ultron_email') || ''
    });
  }

  async refreshAdminUserList() {
    const box = this.$('adminUserList');
    if (!box) return;
    box.textContent = 'Loading…';
    try {
      const data = await this.askWorkerRaw('users', { action: 'list_users', email: OWNER_EMAIL, adminEmail: OWNER_EMAIL });
      const users = data.users || [];
      box.innerHTML = users.length ? users.map(u => '<div>' + this.escape(String(u)) + '</div>').join('') : 'No users yet.';
    } catch (e) {
      box.textContent = 'Could not load users.';
    }
  }

  async registerUserOnServer(email) {
    try { await this.askWorkerRaw('register', { action: 'register', email }); } catch (e) {}
  }

  async fetchRole(email) {
    try {
      const data = await this.askWorkerRaw('role', { action: 'role', email });
      if (data && (data.role === 'admin' || data.role === 'owner')) localStorage.setItem('ultron_is_admin', '1');
      else if (email !== OWNER_EMAIL) localStorage.removeItem('ultron_is_admin');
    } catch (e) {}
  }

  openInformation(fromMenu) {
    this.openInfoModal(!!fromMenu);
  }


}

window.ultronGoogleCallback = function(response) {
  try {
    if (window.ultron && response && response.credential) {
      window.ultron.handleGoogleCredential(response.credential);
    }
  } catch (e) {
    console.error(e);
    alert('Google sign-in failed.');
  }
};

document.addEventListener('DOMContentLoaded', () => {
  speechSynthesis.getVoices();
  window.ultron = new Ultron();
});
